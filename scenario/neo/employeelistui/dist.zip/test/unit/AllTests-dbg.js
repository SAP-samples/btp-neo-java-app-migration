sap.ui.define([
	"javamigrationsample/javamigrationsample/test/unit/controller/Master.controller"
], function () {
	"use strict";
});